% TREEMAPS
%
% Files
%   outline        - Outline all the rectangles in black 
%   plotRectangles - Create patches to display rectangles
%   treemap        - Partition a rectangular area.
%   treemap_demo   - Using Treemap
