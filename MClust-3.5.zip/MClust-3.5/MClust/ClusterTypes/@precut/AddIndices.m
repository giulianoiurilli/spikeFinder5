function MCC = AddIndices(MCC, indices)

MCC.myPoints = union(MCC.myPoints, indices);
