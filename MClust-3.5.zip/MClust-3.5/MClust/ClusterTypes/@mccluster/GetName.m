function name = getName(MCC)

% function name = getName(MCC)
%
% INPUTS
%     MCC - a MCCluster
% REQUIRES
%
% OUTPUTS
%     name
%
% ADR 2008
%
name = MCC.name;
